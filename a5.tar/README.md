press R to record 1 second of sound
relative movement of mouse affects the playback speed 
recorded sound will loop until new sound is recorded
press ESC to stop playing
