open plugins.lua
! touch new.txt
touch plugins.lua
MasonINstallAll
MasonInstallAll
wq!
Debuggables
DapToggleBreakpoint
help ])
])
IndentBlanklineDisable
r
! cargo build && cargo run
cargo clean
wq
q
tabclose
bd
w q9_t1.sql
w q10_t1.sql
w q10_t2.sql
w q10_t3.sql
w q9_t2.sql
w q9_t3.sql
w q9_t4.sql
q10_t4.sql
w q10_t4.sql
q!
w
w | ! cargo build && cargo run

